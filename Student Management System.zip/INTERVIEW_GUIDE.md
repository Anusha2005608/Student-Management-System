# ============================================================
# STUDENT MANAGEMENT SYSTEM
# Complete Interview Preparation Guide
# ============================================================

## 📁 FOLDER STRUCTURE
```
student_management/          ← Root project folder
│
├── app.py                   ← Flask backend (Python server)
├── database_setup.sql       ← SQL commands to set up MySQL
├── requirements.txt         ← Python packages needed
│
└── templates/               ← Flask looks for HTML here (important!)
    └── index.html           ← Frontend (HTML + CSS + JS)
```

## ⚙️ SETUP INSTRUCTIONS (Step by Step)

### Step 1: Install Python Packages
```bash
pip install flask flask-cors mysql-connector-python
```

### Step 2: Set Up MySQL Database
```bash
# Open MySQL terminal
mysql -u root -p

# Run the SQL file
source database_setup.sql;

# OR copy-paste commands from database_setup.sql manually
```

### Step 3: Update Database Password in app.py
Open app.py and find this line:
```python
password="your_password",  # ← Change this to YOUR MySQL password
```

### Step 4: Run the Flask Server
```bash
# Navigate to project folder
cd student_management

# Run the app
python app.py
```
You should see: `Running on http://127.0.0.1:5000`

### Step 5: Open in Browser
Visit: http://localhost:5000


## 🌐 API ENDPOINTS SUMMARY

| Operation | Method | URL              | Body (JSON)                                    |
|-----------|--------|------------------|------------------------------------------------|
| Create    | POST   | /students        | {"name":"Rahul","age":20,"course":"CSE","email":"..."} |
| Read All  | GET    | /students        | (none)                                         |
| Read One  | GET    | /students/{id}   | (none)                                         |
| Update    | PUT    | /students/{id}   | {"name":"Rahul","age":21,"course":"CSE","email":"..."} |
| Delete    | DELETE | /students/{id}   | (none)                                         |


## 💼 INTERVIEW PREPARATION

### ✅ HOW TO EXPLAIN THIS PROJECT IN INTERVIEW

**Perfect 60-second answer:**

> "I built a Student Management System using a full-stack approach.
> The frontend is built with HTML, CSS, and JavaScript, which gives
> users a clean interface to add, view, edit, and delete student records.
>
> The backend is built with Python Flask, which acts as the middle layer
> — it receives requests from the browser, processes them, and interacts
> with the database. I used Flask's routing system to create RESTful API
> endpoints for each CRUD operation.
>
> For the database, I used MySQL with a simple students table containing
> fields like name, age, course, and email. I used parameterized queries
> to prevent SQL injection.
>
> The frontend communicates with the backend using the Fetch API with
> async/await, without any page reload — making it a smooth, SPA-like
> experience.
>
> The key things I learned were: REST API design, HTTP methods, database
> integration with Python, and how frontend and backend communicate."


## ❓ COMMON INTERVIEW QUESTIONS + STRONG ANSWERS

---
### Q1: "What is CRUD?"

**Answer:**
CRUD stands for the four basic operations of any data-driven application:
- **C**reate → Adding new records (INSERT in SQL, POST in HTTP)
- **R**ead → Fetching/viewing records (SELECT in SQL, GET in HTTP)
- **U**pdate → Modifying existing records (UPDATE in SQL, PUT in HTTP)
- **D**elete → Removing records (DELETE in SQL, DELETE in HTTP)

Almost every real-world application — Gmail, Instagram, banking apps —
is built on CRUD at its core.

---
### Q2: "What is a REST API?"

**Answer:**
REST stands for Representational State Transfer. A REST API is a set of
rules for how frontend and backend should communicate.

Key rules:
1. Use HTTP methods correctly (GET=read, POST=create, PUT=update, DELETE=delete)
2. Each URL represents a "resource" (/students represents all students)
3. Use status codes to indicate results (200=OK, 201=Created, 404=Not Found)
4. Server sends data as JSON

In our project, /students is our resource, and we use different HTTP methods
on the same URL to perform different operations.

---
### Q3: "What is Flask?"

**Answer:**
Flask is a lightweight Python web framework. It lets you:
- Define URL routes (which function handles which URL)
- Handle incoming HTTP requests
- Send HTTP responses back

I chose Flask because it's simple, beginner-friendly, and great for
building REST APIs quickly. Unlike Django (another Python framework),
Flask doesn't include everything built-in — you add only what you need.

**Analogy:** Flask is like a basic bike — simple, fast, lightweight.
Django is like a car — more features but heavier.

---
### Q4: "Why did you use MySQL? What is a Primary Key?"

**Answer:**
I chose MySQL because:
- It's free, open-source, and widely used in industry
- It's a relational database — data is stored in organized tables
- It's taught in engineering courses, so I understand it well
- Companies like TCS, Infosys use MySQL in many projects

**Primary Key:** A column that uniquely identifies each row.
In our students table, `id` is the Primary Key.
- Each student has a unique id (1, 2, 3...)
- No two students can have the same id
- It cannot be NULL (empty)
- It's used to refer to specific students in UPDATE and DELETE

**Analogy:** Primary Key is like your Aadhar card number — unique to you,
and used to identify you specifically among millions of people.

---
### Q5: "What is SQL Injection? How did you prevent it?"

**Answer:**
SQL Injection is a security attack where a hacker enters malicious SQL code
in an input field to manipulate the database.

Example attack: If we build queries like this:
```sql
"SELECT * FROM students WHERE name = '" + name + "'"
```
A hacker could type: `'; DROP TABLE students; --`
And the query becomes: `SELECT * FROM students WHERE name = ''; DROP TABLE students; --`
This would DELETE our entire students table!

**Prevention:** I used Parameterized Queries (Prepared Statements):
```python
cursor.execute("SELECT * FROM students WHERE id = %s", (id,))
```
The %s is a placeholder. The MySQL driver "sanitizes" the value before
inserting it, making it impossible for SQL injection to work.

---
### Q6: "What is the difference between GET and POST?"

**Answer:**

| Feature     | GET                          | POST                         |
|-------------|------------------------------|------------------------------|
| Purpose     | Fetch/read data              | Send/create data             |
| Data in     | URL (visible)                | Request body (hidden)        |
| Bookmarkable| Yes                          | No                           |
| Example     | /students (view list)        | /students (add new student)  |
| Secure?     | Less (data in URL)           | More (data in body)          |

---
### Q7: "What is async/await in JavaScript?"

**Answer:**
Network requests (like calling our Flask API) take time.
JavaScript is single-threaded, so if it "waited" normally, the entire
page would freeze while waiting for data.

`async/await` lets JavaScript wait for the response WITHOUT freezing:
- `async` marks a function as asynchronous
- `await` pauses execution of THAT function until the promise resolves,
  while letting other JavaScript code run

```javascript
// Without async/await (wrong way):
const data = fetch('/students');  // data is a Promise, not actual data!

// With async/await (correct way):
const response = await fetch('/students');  // waits for response
const data = await response.json();         // waits for parsing
// Now data has actual student records
```

**Analogy:** You order food and wait (await) while reading your phone.
You're "paused" on the food wait, but your phone works fine.

---
### Q8: "What is CORS? Why did you use it?"

**Answer:**
CORS = Cross-Origin Resource Sharing.

When the browser (frontend at http://localhost:5000) makes a request
to the backend API (also http://localhost:5000 in our case), it follows
the "Same Origin Policy" — a security rule that blocks requests to
different origins (different domain, port, or protocol).

Even if frontend and backend are on same machine but different ports
(e.g., frontend on :3000 and backend on :5000), the browser blocks it.

`flask-cors` adds special headers to our Flask responses that tell the
browser: "Yes, this server allows requests from other origins."

```python
CORS(app)  # Allows all origins to access our API
```

---
### Q9: "What are HTTP Status Codes?"

**Answer:**
Status codes tell the client (browser) what happened with their request.
They're 3-digit numbers grouped into categories:

- **2xx = Success**
  - 200 OK → General success
  - 201 Created → New resource created (we use this when adding student)

- **4xx = Client Error** (problem with the request)
  - 400 Bad Request → Invalid data sent
  - 404 Not Found → Resource doesn't exist

- **5xx = Server Error** (problem on server)
  - 500 Internal Server Error → Unexpected crash on server

---
### Q10: "How does data flow in your project? Explain end-to-end."

**Answer (with example — Adding a student):**

1. **User** fills the form (name, age, course, email) and clicks "Save"

2. **JavaScript** (frontend):
   - Collects form values
   - Creates a JSON object: `{"name":"Rahul","age":20,...}`
   - Makes a POST request to `http://localhost:5000/students`

3. **Flask** (backend) receives the request:
   - The `@app.route('/students', methods=['POST'])` route matches
   - `add_student()` function runs
   - `request.json` reads the JSON data
   - Calls `get_db_connection()` to open MySQL connection
   - Creates a cursor

4. **MySQL** receives the SQL command:
   - `INSERT INTO students (name, age, course, email) VALUES (...)`
   - Adds a new row to the students table
   - Returns confirmation

5. **Flask** sends response:
   - `{"message": "Student added successfully!"}` with status 201

6. **JavaScript** receives response:
   - Shows success message to user
   - Calls `loadStudents()` to refresh the table

7. **User sees** the newly added student in the table

That's the complete request-response cycle! 🔄


## 🐛 COMMON ERRORS AND FIXES

### Error 1: "Access Denied for user 'root'@'localhost'"
**Cause:** Wrong MySQL password in app.py
**Fix:** Update password="your_actual_password" in get_db_connection()

### Error 2: "No module named 'flask'"
**Cause:** Flask not installed
**Fix:** Run: `pip install flask flask-cors mysql-connector-python`

### Error 3: "Failed to fetch" in browser
**Cause:** Flask server not running
**Fix:** Run `python app.py` in terminal first

### Error 4: "TemplateNotFound: index.html"
**Cause:** index.html not inside `templates/` folder
**Fix:** Create folder named `templates` and put index.html inside it

### Error 5: "1062 Duplicate entry for UNIQUE column"
**Cause:** Trying to add student with email that already exists
**Fix:** Use a different email address (email must be unique)

### Error 6: "cors" related error in browser console
**Cause:** flask-cors not installed or CORS(app) missing
**Fix:** Run `pip install flask-cors` and add CORS(app) in app.py


## ✅ BEST PRACTICES (Basic Level)

1. **Never hardcode passwords in code** → Use environment variables
   ```python
   import os
   password = os.environ.get('DB_PASSWORD')
   ```

2. **Always validate input** before saving to database
   - Check if fields are not empty
   - Check age is a valid number
   - Check email format

3. **Use parameterized queries** → Prevents SQL injection

4. **Always close database connections** → Prevents resource leaks

5. **Use meaningful HTTP status codes** in responses

6. **Keep debug=True off in production** → Security risk

7. **Handle errors gracefully** using try/except (Python) and try/catch (JS)

8. **Separate concerns:**
   - HTML → Structure
   - CSS → Styling
   - JavaScript → Logic
   - Python → Business logic
   - MySQL → Data storage

9. **Use version control (Git)** to track your changes

10. **Comment your code** → Helps others (and future you) understand it


## 📊 TECHNOLOGY SUMMARY TABLE

| Technology | Role | Why Used |
|-----------|------|----------|
| HTML | Structure of webpage | Standard for web content |
| CSS | Styling and layout | Makes UI look professional |
| JavaScript | Frontend logic & API calls | Makes page interactive |
| Python | Programming language | Simple, readable, industry-used |
| Flask | Web framework | Lightweight, easy to learn |
| MySQL | Database | Reliable, widely used RDBMS |
| mysql-connector | Python-MySQL bridge | Lets Python talk to MySQL |
| flask-cors | Cross-origin support | Allows frontend-backend communication |
| fetch() API | HTTP requests from browser | Modern, built into browsers |
| async/await | Handle asynchronous code | Cleaner than callbacks/Promises |


## 🎯 QUICK REFERENCE: SQL vs HTTP

| SQL Command | HTTP Method | Operation |
|-------------|-------------|-----------|
| INSERT      | POST        | Create    |
| SELECT      | GET         | Read      |
| UPDATE      | PUT         | Update    |
| DELETE      | DELETE      | Delete    |
